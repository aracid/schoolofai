This HDRI sIBL set is free for your use.

In our online store you can find many other bundled together with their high resolution source hdr files.
With these you can do your own tonemapping and have even greater quality.

Besides those HDRI skies we also have a lot of super high resolution textures.

Weblinks:
http://www.hdri-hub.com/hdrishop
http://www.hdri-hub.com/hdrishop/freesamples
https://www.facebook.com/hdrihub

You can contact us anytime at info@hdri-hub.com

With regards

Your HDRI Hub team